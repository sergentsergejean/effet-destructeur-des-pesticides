/**
 * @module quiz_tests.js
 * @author Nathanaël Grondin
 * @author Mathieu Marcotte
 * @copyright 2018
 */

QUnit.test( "WHEN_question1_THEN_validerQuestion_returns_isGoodAnswer", function( assert ){
    //arrange
    const QUESTION_INDEX = 0;
    const PLAYER_CHOICE = 1;

    //act
    let isGoodAnswer = validerQuestion(QUESTION_INDEX, PLAYER_CHOICE);

    //assert
    const EXEPECTED_RESULT = true;
    assert.equal(isGoodAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3_THEN_validerQuestion_returns_isGoodAnswer", function( assert ){
    //arrange
    const QUESTION_INDEX = 2;
    const PLAYER_CHOICE = 3;

    //act
    let isGoodAnswer = validerQuestion(QUESTION_INDEX, PLAYER_CHOICE);

    //assert
    const EXEPECTED_RESULT = true;
    assert.equal(isGoodAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question5_THEN_validerQuestion_returns_isGoodAnswer", function( assert ){
    //arrange
    const QUESTION_INDEX = 4;
    const PLAYER_CHOICE = 2;

    //act
    let isGoodAnswer = validerQuestion(QUESTION_INDEX, PLAYER_CHOICE);

    //assert
    const EXEPECTED_RESULT = true;
    assert.equal(isGoodAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1IsChosen_THEN_obtenirBonneReponse_returns_goodAnswer", function( assert ){
    //arrange
    const QUESTION_INDEX = 0;

    //act
    let goodAnswer = obtenirBonneReponse(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = 1;
    assert.equal(goodAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question2IsChosen_THEN_obtenirBonneReponse_returns_goodAnswer", function( assert ){
    //arrange
    const QUESTION_INDEX = 1;

    //act
    let goodAnswer = obtenirBonneReponse(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = 0;
    assert.equal(goodAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3IsChosen_THEN_obtenirBonneReponse_returns_goodAnswer", function( assert ){
    //arrange
    const QUESTION_INDEX = 2;

    //act
    let goodAnswer = obtenirBonneReponse(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = 3;
    assert.equal(goodAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_pointsAre0_THEN_ajouterPoint_returns_1", function( assert ){
    //arrange
    totalPointage = 0;
    //act
    ajouterPoint();

    //assert
    const EXEPECTED_RESULT = 1;
    assert.equal(totalPointage, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_pointsAre6_THEN_ajouterPoint_returns_7", function( assert ){
    //arrange
    totalPointage = 6;
    //act
    ajouterPoint();

    //assert
    const EXEPECTED_RESULT = 7;
    assert.equal(totalPointage, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_pointsAre0_THEN_obtenirPointage_returns_1", function( assert ){
    //arrange
    totalPointage = 0;
    //act
    obtenirPointage();

    //assert
    const EXEPECTED_RESULT = 0;
    assert.equal(totalPointage, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_pointsAre6_THEN_obtenirPointage_returns_7", function( assert ){
    //arrange
    totalPointage = 6;
    //act
    obtenirPointage();

    //assert
    const EXEPECTED_RESULT = 6;
    assert.equal(totalPointage, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1IsChosen_THEN_obtenirChoix_returns_tableOfAnswer", function( assert ){
    //arrange
    const QUESTION_INDEX = 0;
    //act
    var tableOfAnswer = obtenirChoix(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = ["Q1R0", "Q1R1", "Q1R2", "Q1R3"];
    assert.deepEqual(tableOfAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question2IsChosen_THEN_obtenirChoix_returns_tableOfAnswer", function( assert ){
    //arrange
    const QUESTION_INDEX = 1;
    //act
    var tableOfAnswer = obtenirChoix(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = ["Q2R0", "Q2R1", "Q2R2", "Q2R3"];
    assert.deepEqual(tableOfAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3IsChosen_THEN_obtenirChoix_returns_tableOfAnswer", function( assert ){
    //arrange
    const QUESTION_INDEX = 2;
    //act
    var tableOfAnswer = obtenirChoix(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = ["Q3R0", "Q3R1", "Q3R2", "Q3R3"];
    assert.deepEqual(tableOfAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3IsChosen_THEN_estFinPartie_returns_false", function( assert ){
    //arrange
    const QUESTION_INDEX = 2;
    //act
    var tableOfAnswer = estFinPartie(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = false;
    assert.equal(tableOfAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question4IsChosen_THEN_estFinPartie_returns_false", function( assert ){
    //arrange
    const QUESTION_INDEX = 3;
    //act
    var tableOfAnswer = estFinPartie(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = false;
    assert.equal(tableOfAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question5IsChosen_THEN_estFinPartie_returns_true", function( assert ){
    //arrange
    const QUESTION_INDEX = 4;
    //act
    var tableOfAnswer = estFinPartie(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = true;
    assert.equal(tableOfAnswer, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_reachQuestion1_THEN_chargerQuestionSuivante_returns_1", function( assert ){
    //arrange
    questionCourante = 0;
    //act
    chargerQuestionSuivante();

    //assert
    const EXEPECTED_RESULT = 1;
    assert.equal(questionCourante, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_reachQuestion4_THEN_chargerQuestionSuivante_returns_4", function( assert ){
    //arrange
    questionCourante = 3;
    //act
    chargerQuestionSuivante();

    //assert
    const EXEPECTED_RESULT = 4;
    assert.equal(questionCourante, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_reachQuestion5_THEN_chargerQuestionSuivante_returns_5", function( assert ){
    //arrange
    questionCourante = 4;
    //act
    chargerQuestionSuivante();

    //assert
    const EXEPECTED_RESULT = 5;
    assert.equal(questionCourante, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1_THEN_afficherBonneReponse_returns_element", function( assert ){
    //arrange
    const QUESTION_INDEX = 0;
    //act
    var afficher = afficherBonneReponse(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = document.getElementById("texteReponse").innerText;
    assert.equal(afficher, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question4_THEN_afficherBonneReponse_returns_element", function( assert ){
    //arrange
    const QUESTION_INDEX = 3;
    //act
    var afficher = afficherBonneReponse(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = document.getElementById("texteReponse").innerText;
    assert.equal(afficher, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3_THEN_afficherBonneReponse_returns_element", function( assert ){
    //arrange
    const QUESTION_INDEX = 2;
    //act
    var afficher = afficherBonneReponse(QUESTION_INDEX);

    //assert
    const EXEPECTED_RESULT = document.getElementById("texteReponse").innerText;
    assert.equal(afficher, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_pointsIs0_THEN_majPointage_returns_element", function( assert ){
    //arrange
    totalPointage = 0;
    //act
    var majPoints = majPointage();

    //assert
    const EXEPECTED_RESULT = document.getElementById("totalPoints").value;
    assert.equal(majPoints, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_pointsIs4_THEN_majPointage_returns_element", function( assert ){
    //arrange
    totalPointage = 4;
    //act
    var majPoints = majPointage();

    //assert
    const EXEPECTED_RESULT = document.getElementById("totalPoints").value;
    assert.equal(majPoints, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_pointsIs1_THEN_majPointage_returns_element", function( assert ){
    //arrange
    totalPointage = 1;
    //act
    var majPoints = majPointage();

    //assert
    const EXEPECTED_RESULT = document.getElementById("totalPoints").value;
    assert.equal(majPoints, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1_THEN_majTotalQuestion_returns_element", function( assert ){
    //arrange
    questionCourante = 0;
    //act
    var majQuestion = majTotalQuestion();

    //assert
    const EXEPECTED_RESULT = document.getElementById("noQuestionCourante").value;
    assert.equal(majQuestion, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question2_THEN_majTotalQuestion_returns_element", function( assert ){
    //arrange
    questionCourante = 1;
    //act
    var majQuestion = majTotalQuestion();

    //assert
    const EXEPECTED_RESULT = document.getElementById("noQuestionCourante").value;
    assert.equal(majQuestion, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question4_THEN_majTotalQuestion_returns_element", function( assert ){
    //arrange
    questionCourante = 3;
    //act
    var majQuestion = majTotalQuestion();

    //assert
    const EXEPECTED_RESULT = document.getElementById("noQuestionCourante").value;
    assert.equal(majQuestion, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1_THEN_majTexteChoix_returns_element", function( assert ){
    //arrange
    questionCourante = 0;
    //act
    var majChoice = majTexteChoix(questionCourante);

    //assert
    const EXEPECTED_RESULT = document.getElementById("boiteChoix").value;
    assert.equal(majChoice, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question5_THEN_majTexteChoix_returns_element", function( assert ){
    //arrange
    questionCourante = 4;
    //act
    var majChoice = majTexteChoix(questionCourante);

    //assert
    const EXEPECTED_RESULT = document.getElementById("boiteChoix").value;
    assert.equal(majChoice, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3_THEN_majTexteChoix_returns_element", function( assert ){
    //arrange
    questionCourante = 2;
    //act
    var majChoice = majTexteChoix(questionCourante);

    //assert
    const EXEPECTED_RESULT = document.getElementById("boiteChoix").value;
    assert.equal(majChoice, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1_THEN_majTexteQuestion_returns_element", function( assert ){
    //arrange
    questionCourante = 0;
    //act
    var majQuestionTxt = majTexteQuestion(questionCourante);

    //assert
    const EXEPECTED_RESULT = document.getElementById("texteQuestion").value;
    assert.equal(majQuestionTxt, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3_THEN_majTexteQuestion_returns_element", function( assert ){
    //arrange
    questionCourante = 2;
    //act
    var majQuestionTxt = majTexteQuestion(questionCourante);

    //assert
    const EXEPECTED_RESULT = document.getElementById("texteQuestion").value;
    assert.equal(majQuestionTxt, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question5_THEN_majTexteQuestion_returns_element", function( assert ){
    //arrange
    questionCourante = 4;
    //act
    var majQuestionTxt = majTexteQuestion(questionCourante);

    //assert
    const EXEPECTED_RESULT = document.getElementById("texteQuestion").value;
    assert.equal(majQuestionTxt, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3_THEN_majNoQuestionCourant_returns_element", function( assert ){
    //arrange
    questionCourante = 2;
    //act
    var majQuestion = majNoQuestionCourant();

    //assert
    const EXEPECTED_RESULT = document.getElementById("boiteChoix").value;
    assert.equal(majQuestion, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1_THEN_majNoQuestionCourant_returns_element", function( assert ){
    //arrange
    questionCourante = 0;
    //act
    var majQuestion = majNoQuestionCourant();

    //assert
    const EXEPECTED_RESULT = document.getElementById("boiteChoix").value;
    assert.equal(majQuestion, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question5_THEN_majNoQuestionCourant_returns_element", function( assert ){
    //arrange
    questionCourante = 4;
    //act
    var majQuestion = majNoQuestionCourant();

    //assert
    const EXEPECTED_RESULT = document.getElementById("boiteChoix").value;
    assert.equal(majQuestion, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1_THEN_majProgression_returns_element", function( assert ){
    //arrange
    questionCourante = 0;
    //act
    var majLine = majProgression();

    //assert
    const EXEPECTED_RESULT = document.getElementById("barreProgression").value;
    assert.equal(majLine, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3_THEN_majProgression_returns_element", function( assert ){
    //arrange
    questionCourante = 2;
    //act
    var majLine = majProgression();

    //assert
    const EXEPECTED_RESULT = document.getElementById("barreProgression").value;
    assert.equal(majLine, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question5_THEN_majProgression_returns_element", function( assert ){
    //arrange
    questionCourante = 4;
    //act
    var majLine = majProgression();

    //assert
    const EXEPECTED_RESULT = document.getElementById("barreProgression").value;
    assert.equal(majLine, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_wrongAnswer_THEN_afficherBoiteMauvaiseReponse_returns_modalReponse", function( assert ){
    //act
    afficherBoiteMauvaiseReponse(0);
    var wrongAnswerBoxDisplay = document.getElementById("modalReponse").style.display;

    //assert
    var EXEPECTED_RESULT = "block"
    console.log(document.getElementById("modalReponse").style.display);
    assert.equal(wrongAnswerBoxDisplay, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_wrongAnswer_THEN_afficherBoiteMauvaiseReponse_returns_modalReponse", function( assert ){
    //act
    afficherBoiteMauvaiseReponse(0);
    var wrongAnswerBoxDisplay = document.getElementById("modalReponse").style.display;

    //assert
    var EXEPECTED_RESULT = "block"
    assert.equal(wrongAnswerBoxDisplay, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1_THEN_afficherBoiteMauvaiseReponse_returns_element", function( assert ){
    //arrange
    questionCourante = 0;
    reponseUtilisateur = 0;

    //act
    afficherBoiteMauvaiseReponse(questionCourante);
    var wrongAnswerBoxText = document.getElementById("texteReponse").innerText;

    //assert
    var EXEPECTED_RESULT = 	"Q1R1 et non Q1R0";
    assert.equal(wrongAnswerBoxText, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3_THEN_afficherBoiteMauvaiseReponse_returns_element", function( assert ){
    //arrange
    questionCourante = 2;
    reponseUtilisateur = 1;

    //act
    afficherBoiteMauvaiseReponse(questionCourante);
    var wrongAnswerBoxText = document.getElementById("texteReponse").innerText;

    //assert
    var EXEPECTED_RESULT = 	"Q3R3 et non Q3R1";
    assert.equal(wrongAnswerBoxText, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1_THEN_lienPlusInfos_returns_element", function( assert ){
    //arrange
    questionCourante = 0;
    reponseUtilisateur = 0;

    //act
    afficherBoiteMauvaiseReponse(questionCourante);
    var wrongAnswerBoxHyperlink = document.getElementById("lienPlusInfos").innerText;

    //assert
    var EXEPECTED_RESULT = 	"https://www.q1.com/";
    assert.equal(wrongAnswerBoxHyperlink, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3_THEN_lienPlusInfos_returns_element", function( assert ){
    //arrange
    questionCourante = 2;
    reponseUtilisateur = 1;

    //act
    afficherBoiteMauvaiseReponse(questionCourante);
    var wrongAnswerBoxHyperlink = document.getElementById("lienPlusInfos").innerText;

    //assert
    var EXEPECTED_RESULT = 	"https://www.q3.com/";
    assert.equal(wrongAnswerBoxHyperlink, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question1_THEN_lienPlusInfos_returns_element", function( assert ){
    //arrange
    questionCourante = 0;
    reponseUtilisateur = 0;

    //act
    afficherBoiteMauvaiseReponse(questionCourante);
    var wrongAnswerBoxHref = document.getElementById("lienPlusInfos").href;

    //assert
    var EXEPECTED_RESULT = 	"https://www.q1.com/";
    assert.equal(wrongAnswerBoxHref, EXEPECTED_RESULT);
});

QUnit.test( "WHEN_question3_THEN_lienPlusInfos_returns_element", function( assert ){
    //arrange
    questionCourante = 2;
    reponseUtilisateur = 1;

    //act
    afficherBoiteMauvaiseReponse(questionCourante);
    var wrongAnswerBoxHref = document.getElementById("lienPlusInfos").href;

    //assert
    var EXEPECTED_RESULT = 	"https://www.q3.com/";
    assert.equal(wrongAnswerBoxHref, EXEPECTED_RESULT);
});